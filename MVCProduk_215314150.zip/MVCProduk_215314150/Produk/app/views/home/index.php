<div class="container mt-5">

    <div class="row">
        <div class="col-6">
            <h3>Daftar Produk</h3>

            <table class="table table-bordered">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Nama</th>
                    <th>Harga</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($data['barang'] as $barang) : ?>
                    <tr>
                        <td><?= $barang['id']; ?></td>
                        <td><?= $barang['NamaProduk']; ?></td>
                        <td><?= $barang['Harga']; ?></td>
                        <td>
                            <a href="<?= BASEURL; ?>/produk/detail/<?= $barang['id']; ?>" class="btn btn-primary">Detail</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
