<?php
define('BASEURL', 'http://localhost/produk_mvc');

//DB
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'produk_mvc');