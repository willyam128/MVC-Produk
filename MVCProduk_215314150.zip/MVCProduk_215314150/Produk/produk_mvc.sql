-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Waktu pembuatan: 19 Jun 2023 pada 05.13
-- Versi server: 10.4.28-MariaDB
-- Versi PHP: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `produk_mvc`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `produkmvc`
--

CREATE TABLE `produkmvc` (
  `id` int(90) NOT NULL,
  `NamaProduk` varchar(90) NOT NULL,
  `Harga` int(90) NOT NULL,
  `Exp` varchar(90) NOT NULL,
  `Brand` varchar(90) NOT NULL,
  `DistributorProduk` varchar(90) NOT NULL,
  `FotoProduk` varchar(225) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `produkmvc`
--

INSERT INTO `produkmvc` (`id`, `NamaProduk`, `Harga`, `Exp`, `Brand`, `DistributorProduk`, `FotoProduk`) VALUES
(1, 'Rinso', 12000, '21122025', 'Unilever', 'PT.IndoMakmur', 'rinso'),
(2, 'Indomie', 2500, '22032024', 'Indofood', 'PT.JayaAbdi', 'indomie'),
(3, 'Paseo', 7000, '03082026', 'Univenus', 'PT.Curut', 'paseo');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
