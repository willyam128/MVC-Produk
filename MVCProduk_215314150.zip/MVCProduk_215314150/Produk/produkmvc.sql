-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 18, 2023 at 04:34 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.1.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `produk_mvc`
--

-- --------------------------------------------------------

--
-- Table structure for table `produkmvc`
--

CREATE TABLE `produkmvc` (
  `id` int(90) DEFAULT NULL,
  `NamaProduk` varchar(90) NOT NULL,
  `Harga` int(90) NOT NULL,
  `Exp` varchar(90) NOT NULL,
  `Brand` varchar(90) NOT NULL,
  `DistributorProduk` varchar(90) NOT NULL,
  `FotoProduk` varchar(225) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `produkmvc`
--

INSERT INTO `produkmvc` (`id`, `NamaProduk`, `Harga`, `Exp`, `Brand`, `DistributorProduk`, `FotoProduk`) VALUES
(1, 'Rinso', 12000, '21122025', 'Unilever', 'PT.IndoMakmur', 'pepsodent'),
(2, 'Indomie', 2500, '22032024', 'Indofood', 'PT.JayaAbdi', 'wipol'),
(3, 'Paseo', 7000, '03082026', 'Univenus', 'PT.Curut', 'walls');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
